CREATE  PROCEDURE DropColumnWithDefaultConstraintsAndIndex
    -- Add the parameters for the stored procedure here
    @tableName nvarchar(max), 
    @columnName nvarchar(max)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;
	--default value constraint
    DECLARE @ConstraintName nvarchar(200);
    
	SELECT @ConstraintName 
    FROM sys.default_constraints dc
    WHERE dc.parent_object_id = OBJECT_ID(@tableName) 
        AND dc.parent_column_id = (SELECT column_id FROM sys.columns c WHERE c.name = (@columnName) 
        AND c.object_id = OBJECT_ID(@tableName));

    IF @ConstraintName IS NOT NULL
        EXEC('ALTER TABLE ' + @tableName + ' DROP CONSTRAINT ' + @ConstraintName);


  -- index
    CREATE TABLE #dependencies(
       dep_name varchar(100),
       dep_type varchar(50));

		INSERT INTO #dependencies
		SELECT i.name, 'I'
		FROM sys.indexes i
		JOIN sys.index_columns ic ON ic.index_id = i.index_id and ic.object_id=i.object_id
		JOIN sys.columns c ON c.column_id = ic.column_id and c.object_id=i.object_id
		JOIN sys.objects o ON o.object_id = i.object_id
		where o.name = @tableName AND i.type=2 AND c.name = @columnName AND is_unique_constraint = 0

  -- statistic

 
		INSERT INTO #dependencies
		SELECT s.name, 'S'
		FROM sys.stats AS s
		INNER JOIN sys.stats_columns AS sc 
			ON s.object_id = sc.object_id AND s.stats_id = sc.stats_id
		INNER JOIN sys.columns AS c 
			ON sc.object_id = c.object_id AND c.column_id = sc.column_id
		WHERE s.object_id = OBJECT_ID(@tableName)
		AND c.name = @columnName
		AND s.name LIKE '_dta_stat%';

		DECLARE @dep_name nvarchar(500);
		DECLARE @type nchar(1);

		DECLARE dep_cursor CURSOR
		FOR SELECT * FROM #dependencies;

		OPEN dep_cursor;

		FETCH NEXT FROM dep_cursor 
		INTO @dep_name, @type;

		DECLARE @sql nvarchar(max);

		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @sql = 
				CASE @type
					WHEN 'I' THEN 'DROP INDEX [' + @dep_name + '] ON dbo.[' + @tableName + ']'
					WHEN 'S' THEN 'DROP STATISTICS [' + @tableName + '].[' + @dep_name + ']'
				END
			print @sql
			EXEC sp_executesql @sql
			FETCH NEXT FROM dep_cursor 
			INTO @dep_name, @type;
		END

		DEALLOCATE dep_cursor;

		DROP TABLE #dependencies;


        EXEC('ALTER TABLE ' + @tableName + ' DROP COLUMN ' + @columnName)       
END

