create or replace view V_ORG as
  select p.party_id as org_id,p.org_parent_org_id as parent_org_id,p.party_name as org_name,p.party_code as org_code
    from t_pty_party p
    where p.party_type in (3)
   
