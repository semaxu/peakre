if object_id('dbo.DropColumnWithDefaultConstraintsAndIndex', 'p') is not null
    drop procedure DropColumnWithDefaultConstraintsAndIndex
